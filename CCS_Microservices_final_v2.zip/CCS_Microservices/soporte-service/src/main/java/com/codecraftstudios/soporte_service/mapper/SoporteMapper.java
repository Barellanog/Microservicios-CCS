package com.codecraftstudios.soporte_service.mapper;

import com.codecraftstudios.soporte_service.dto.SoporteDTO;
import com.codecraftstudios.soporte_service.model.Soporte;

public class SoporteMapper {

    public static SoporteDTO toDTO(Soporte soporte) {
        return new SoporteDTO(
                soporte.getId(),
                soporte.getTitulo(),
                soporte.getDescripcion(),
                soporte.getRemitenteEmail(),
                soporte.getEstado()
        );
    }

    public static Soporte toEntity(SoporteDTO dto) {
        Soporte soporte = new Soporte();
        soporte.setId(dto.getId());
        soporte.setTitulo(dto.getTitulo());
        soporte.setDescripcion(dto.getDescripcion());
        soporte.setRemitenteEmail(dto.getRemitenteEmail());
        soporte.setEstado(dto.getEstado());
        return soporte;
    }
}
