package com.codecraftstudios.soporte_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages = {
		"com.codecraftstudios.soporte_service",
		"com.codecraftstudios.shared"
})
public class SoporteServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(SoporteServiceApplication.class, args);
	}

}
