package com.codecraftstudios.estudiante_service.service;

import com.codecraftstudios.estudiante_service.model.Estudiante;
import com.codecraftstudios.estudiante_service.repository.EstudianteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class EstudianteService {

    @Autowired
    private EstudianteRepository estudianteRepository;

    public List<Estudiante> listarEstudiantes() {
        return estudianteRepository.findAll();
    }

    public Optional<Estudiante> obtenerEstudiantePorId(Long id) {
        return estudianteRepository.findById(id);
    }

    public Estudiante crearEstudiante(Estudiante estudiante) {
        return estudianteRepository.save(estudiante);
    }

    public Optional<Estudiante> actualizarEstudiante(Long id, Estudiante nuevoEstudiante) {
        return estudianteRepository.findById(id).map(estudianteExistente -> {
            estudianteExistente.setNombre(nuevoEstudiante.getNombre());
            estudianteExistente.setEmail(nuevoEstudiante.getEmail());
            estudianteExistente.setCarrera(nuevoEstudiante.getCarrera());
            return estudianteRepository.save(estudianteExistente);
        });
    }

    public void eliminarEstudiante(Long id) {
        estudianteRepository.deleteById(id);
    }
}
