package com.codecraftstudios.shared.enums;

public enum Rol {
    ESTUDIANTE,
    INSTRUCTOR,
    GERENTE,
    ADMIN,
    SOPORTE_TECNICO
}
