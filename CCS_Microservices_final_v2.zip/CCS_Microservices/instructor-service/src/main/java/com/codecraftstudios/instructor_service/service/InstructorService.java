package com.codecraftstudios.instructor_service.service;

import com.codecraftstudios.instructor_service.model.Instructor;
import com.codecraftstudios.instructor_service.repository.InstructorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class InstructorService {

    @Autowired
    private InstructorRepository instructorRepository;

    public List<Instructor> listarInstructores() {
        return instructorRepository.findAll();
    }

    public Optional<Instructor> obtenerInstructorPorId(Long id) {
        return instructorRepository.findById(id);
    }

    public Instructor crearInstructor(Instructor instructor) {
        return instructorRepository.save(instructor);
    }

    public Optional<Instructor> actualizarInstructor(Long id, Instructor nuevoInstructor) {
        return instructorRepository.findById(id).map(instructorExistente -> {
            instructorExistente.setNombre(nuevoInstructor.getNombre());
            instructorExistente.setEmail(nuevoInstructor.getEmail());
            instructorExistente.setEspecialidad(nuevoInstructor.getEspecialidad());
            return instructorRepository.save(instructorExistente);
        });
    }

    public void eliminarInstructor(Long id) {
        instructorRepository.deleteById(id);
    }
}
