package com.codecraftstudios.instructor_service.model;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "instructores")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Instructor {

    @Id
    private Long id; // ID ingresado manualmente

    @Column(nullable = false)
    private String nombre;

    @Column(nullable = false, unique = true)
    private String email;

    @Column(nullable = false)
    private String especialidad;
}
