package com.codecraftstudios.instructor_service.controller;

import com.codecraftstudios.instructor_service.dto.InstructorDTO;
import com.codecraftstudios.instructor_service.mapper.InstructorMapper;
import com.codecraftstudios.instructor_service.model.Instructor;
import com.codecraftstudios.instructor_service.service.InstructorService;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/v1/instructores")
public class InstructorController {

    @Autowired
    private InstructorService instructorService;

    @GetMapping
    public ResponseEntity<List<InstructorDTO>> listar() {
        List<InstructorDTO> instructores = instructorService.listarInstructores()
                .stream()
                .map(InstructorMapper::toDTO)
                .collect(Collectors.toList());

        return instructores.isEmpty()
                ? ResponseEntity.noContent().build()
                : ResponseEntity.ok(instructores);
    }

    @GetMapping("/{id}")
    public ResponseEntity<InstructorDTO> obtenerPorId(@PathVariable Long id) {
        return instructorService.obtenerInstructorPorId(id)
                .map(InstructorMapper::toDTO)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<InstructorDTO> crear(@RequestBody InstructorDTO dto) {
        Instructor creado = instructorService.crearInstructor(InstructorMapper.toEntity(dto));
        return ResponseEntity.status(201).body(InstructorMapper.toDTO(creado));
    }

    @PutMapping("/{id}")
    public ResponseEntity<InstructorDTO> actualizar(@PathVariable Long id, @RequestBody InstructorDTO dto) {
        return instructorService.actualizarInstructor(id, InstructorMapper.toEntity(dto))
                .map(InstructorMapper::toDTO)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        instructorService.eliminarInstructor(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/panel")
    public ResponseEntity<?> verPanel(HttpServletRequest request) {
        String rol = (String) request.getAttribute("usuarioRol");
        String email = (String) request.getAttribute("usuarioEmail");

        if (!"INSTRUCTOR".equals(rol)) {
            return ResponseEntity.status(403).body("Acceso denegado");
        }

        return ResponseEntity.ok("Bienvenido instructor: " + email);
    }

}
