package com.codecraftstudios.auth_service.model;

public enum Rol {
    ESTUDIANTE,
    INSTRUCTOR,
    GERENTE,
    ADMIN,
    SOPORTE_TECNICO
}
