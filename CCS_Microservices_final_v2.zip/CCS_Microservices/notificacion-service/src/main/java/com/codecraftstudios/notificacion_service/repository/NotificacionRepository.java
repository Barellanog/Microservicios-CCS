package com.codecraftstudios.notificacion_service.repository;

import com.codecraftstudios.notificacion_service.model.Notificacion;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface NotificacionRepository extends JpaRepository<Notificacion, Long> {

    List<Notificacion> findByDestinatarioEmail(String destinatarioEmail);

    List<Notificacion> findByEstado(String estado);

    List<Notificacion> findByTipo(String tipo);
}
