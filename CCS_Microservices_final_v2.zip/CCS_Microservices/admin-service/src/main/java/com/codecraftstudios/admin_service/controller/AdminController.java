package com.codecraftstudios.admin_service.controller;

import com.codecraftstudios.admin_service.dto.AdminDTO;
import com.codecraftstudios.admin_service.mapper.AdminMapper;
import com.codecraftstudios.admin_service.model.Admin;
import com.codecraftstudios.admin_service.service.AdminService;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/v1/admins")
public class AdminController {

    @Autowired
    private AdminService adminService;

    @GetMapping
    public ResponseEntity<List<AdminDTO>> listar() {
        List<AdminDTO> admins = adminService.listarAdmins()
                .stream()
                .map(AdminMapper::toDTO)
                .collect(Collectors.toList());

        return admins.isEmpty()
                ? ResponseEntity.noContent().build()
                : ResponseEntity.ok(admins);
    }

    @GetMapping("/{id}")
    public ResponseEntity<AdminDTO> obtenerPorId(@PathVariable Long id) {
        return adminService.obtenerAdminPorId(id)
                .map(AdminMapper::toDTO)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<AdminDTO> crear(@RequestBody AdminDTO dto) {
        Admin creado = adminService.crearAdmin(AdminMapper.toEntity(dto));
        return ResponseEntity.status(201).body(AdminMapper.toDTO(creado));
    }

    @PutMapping("/{id}")
    public ResponseEntity<AdminDTO> actualizar(@PathVariable Long id, @RequestBody AdminDTO dto) {
        return adminService.actualizarAdmin(id, AdminMapper.toEntity(dto))
                .map(AdminMapper::toDTO)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        adminService.eliminarAdmin(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/configuracion")
    public ResponseEntity<?> verConfiguracion(HttpServletRequest request) {
        String rol = (String) request.getAttribute("usuarioRol");
        String email = (String) request.getAttribute("usuarioEmail");

        if (!"ADMIN".equals(rol)) {
            return ResponseEntity.status(403).body("Acceso denegado");
        }

        return ResponseEntity.ok("Configuraciones visibles por " + email);
    }
}
