package com.codecraftstudios.admin_service.config;

import com.codecraftstudios.shared.security.TokenAuthFilter;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {

    @Bean
    public FilterRegistrationBean<TokenAuthFilter> registrarFiltro(TokenAuthFilter filtro) {
        FilterRegistrationBean<TokenAuthFilter> bean = new FilterRegistrationBean<>();
        bean.setFilter(filtro);

        // Aplica el filtro a todas las rutas protegidas de admin_service
        bean.addUrlPatterns("/api/v1/admins/*");

        return bean;
    }
}
