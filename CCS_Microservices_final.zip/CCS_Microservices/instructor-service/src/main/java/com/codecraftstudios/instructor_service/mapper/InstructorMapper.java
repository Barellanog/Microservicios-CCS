package com.codecraftstudios.instructor_service.mapper;

import com.codecraftstudios.instructor_service.dto.InstructorDTO;
import com.codecraftstudios.instructor_service.model.Instructor;

public class InstructorMapper {

    public static InstructorDTO toDTO(Instructor instructor) {
        return new InstructorDTO(
                instructor.getId(),
                instructor.getNombre(),
                instructor.getEmail(),
                instructor.getEspecialidad()
        );
    }

    public static Instructor toEntity(InstructorDTO dto) {
        Instructor instructor = new Instructor();
        instructor.setId(dto.getId());
        instructor.setNombre(dto.getNombre());
        instructor.setEmail(dto.getEmail());
        instructor.setEspecialidad(dto.getEspecialidad());
        return instructor;
    }
}
