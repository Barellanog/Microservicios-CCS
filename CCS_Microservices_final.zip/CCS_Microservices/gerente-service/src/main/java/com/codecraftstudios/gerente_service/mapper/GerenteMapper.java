package com.codecraftstudios.gerente_service.mapper;

import com.codecraftstudios.gerente_service.dto.GerenteDTO;
import com.codecraftstudios.gerente_service.model.Gerente;

public class GerenteMapper {

    public static GerenteDTO toDTO(Gerente gerente) {
        return new GerenteDTO(
                gerente.getId(),
                gerente.getNombre(),
                gerente.getEmail(),
                gerente.getAreaResponsable()
        );
    }

    public static Gerente toEntity(GerenteDTO dto) {
        Gerente gerente = new Gerente();
        gerente.setId(dto.getId());
        gerente.setNombre(dto.getNombre());
        gerente.setEmail(dto.getEmail());
        gerente.setAreaResponsable(dto.getAreaResponsable());
        return gerente;
    }
}
