package com.codecraftstudios.gerente_service.controller;

import com.codecraftstudios.gerente_service.dto.GerenteDTO;
import com.codecraftstudios.gerente_service.mapper.GerenteMapper;
import com.codecraftstudios.gerente_service.model.Gerente;
import com.codecraftstudios.gerente_service.service.GerenteService;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/v1/gerentes")
public class GerenteController {

    @Autowired
    private GerenteService gerenteService;

    @GetMapping
    public ResponseEntity<List<GerenteDTO>> listar() {
        List<GerenteDTO> gerentes = gerenteService.listarGerentes()
                .stream()
                .map(GerenteMapper::toDTO)
                .collect(Collectors.toList());

        return gerentes.isEmpty()
                ? ResponseEntity.noContent().build()
                : ResponseEntity.ok(gerentes);
    }

    @GetMapping("/{id}")
    public ResponseEntity<GerenteDTO> obtenerPorId(@PathVariable Long id) {
        return gerenteService.obtenerGerentePorId(id)
                .map(GerenteMapper::toDTO)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<GerenteDTO> crear(@RequestBody GerenteDTO dto) {
        Gerente creado = gerenteService.crearGerente(GerenteMapper.toEntity(dto));
        return ResponseEntity.status(201).body(GerenteMapper.toDTO(creado));
    }

    @PutMapping("/{id}")
    public ResponseEntity<GerenteDTO> actualizar(@PathVariable Long id, @RequestBody GerenteDTO dto) {
        return gerenteService.actualizarGerente(id, GerenteMapper.toEntity(dto))
                .map(GerenteMapper::toDTO)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        gerenteService.eliminarGerente(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/panel")
    public ResponseEntity<?> verPanel(HttpServletRequest request) {
        String rol = (String) request.getAttribute("usuarioRol");
        String email = (String) request.getAttribute("usuarioEmail");

        if (!"GERENTE".equals(rol)) {
            return ResponseEntity.status(403).body("Acceso denegado");
        }

        return ResponseEntity.ok("Panel de gerente para: " + email);
    }

}
