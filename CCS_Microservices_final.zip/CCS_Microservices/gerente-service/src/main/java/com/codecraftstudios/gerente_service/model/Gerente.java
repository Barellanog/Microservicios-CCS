package com.codecraftstudios.gerente_service.model;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "gerentes")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Gerente {

    @Id
    private Long id;

    @Column(nullable = false)
    private String nombre;

    @Column(nullable = false, unique = true)
    private String email;

    @Column(nullable = false)
    private String areaResponsable;
}
