package com.codecraftstudios.auth_service.dto;

import com.codecraftstudios.auth_service.model.Rol;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class TokenValidationResponse {
    private boolean valido;
    private String email;
    private Rol rol;
}
