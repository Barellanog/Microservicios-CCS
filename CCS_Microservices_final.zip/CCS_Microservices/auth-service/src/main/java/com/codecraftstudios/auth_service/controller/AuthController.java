package com.codecraftstudios.auth_service.controller;

import com.codecraftstudios.auth_service.dto.*;
import com.codecraftstudios.auth_service.service.AuthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/auth")
public class AuthController {

    @Autowired
    private AuthService authService;

    // Registro de usuario
    @PostMapping("/register")
    public ResponseEntity<AuthResponse> registrar(@RequestBody RegistroRequest request) {
        AuthResponse response = authService.registrar(request);
        return ResponseEntity.ok(response);
    }

    // Login de usuario
    @PostMapping("/login")
    public ResponseEntity<AuthResponse> login(@RequestBody LoginRequest request) {
        AuthResponse response = authService.login(request);
        return ResponseEntity.ok(response);
    }

    // Validación de token desde otros microservicios
    @GetMapping("/validate-token")
    public ResponseEntity<TokenValidationResponse> validar(@RequestParam String token) {
        TokenValidationResponse response = authService.validarToken(token);
        return ResponseEntity.ok(response);
    }
}
