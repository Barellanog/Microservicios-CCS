package com.codecraftstudios.auth_service.dto;

import com.codecraftstudios.auth_service.model.Rol;
import lombok.Data;

@Data
public class RegistroRequest {
    private String nombre;
    private String email;
    private String password;
    private Rol rol;
}
