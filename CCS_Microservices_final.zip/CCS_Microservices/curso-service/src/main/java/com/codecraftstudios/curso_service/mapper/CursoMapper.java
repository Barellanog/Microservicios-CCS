package com.codecraftstudios.curso_service.mapper;

import com.codecraftstudios.curso_service.dto.CursoDTO;
import com.codecraftstudios.curso_service.model.Curso;

import java.time.LocalDate;

public class CursoMapper {

    public static CursoDTO toDTO(Curso curso) {
        return new CursoDTO(
                curso.getId(),
                curso.getNombre(),
                curso.getDescripcion(),
                curso.getFecha().toString(), // LocalDate → String
                curso.getHoraCurso()
        );
    }

    public static Curso toEntity(CursoDTO dto) {
        Curso curso = new Curso();
        curso.setId(dto.getId());
        curso.setNombre(dto.getNombre());
        curso.setDescripcion(dto.getDescripcion());

        // Validar si dto.getFecha() no es null o vacía antes de parsear
        if (dto.getFecha() != null && !dto.getFecha().isEmpty()) {
            curso.setFecha(LocalDate.parse(dto.getFecha()));
        }

        curso.setHoraCurso(dto.getHoraCurso());
        return curso;
    }
}
