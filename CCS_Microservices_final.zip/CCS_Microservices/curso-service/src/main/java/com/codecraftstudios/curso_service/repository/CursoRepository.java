package com.codecraftstudios.curso_service.repository;

import com.codecraftstudios.curso_service.model.Curso;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Repository
public interface CursoRepository extends JpaRepository<Curso, Long> {

    Optional<Curso> findById(Long id);

    Optional<Curso> findByNombre(String nombre);

    List<Curso> findByFecha(LocalDate fecha);

    List<Curso> findByHoraCurso(String horaCurso);
}
