package com.codecraftstudios.shared.dto;

import com.codecraftstudios.shared.enums.Rol;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TokenValidationResponse {
    private boolean valido;
    private String email;
    private Rol rol;
}
