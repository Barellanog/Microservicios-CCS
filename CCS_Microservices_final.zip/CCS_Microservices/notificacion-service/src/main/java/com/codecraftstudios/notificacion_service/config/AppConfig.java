package com.codecraftstudios.notificacion_service.config;

import com.codecraftstudios.shared.security.TokenAuthFilter;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {

    @Bean
    public FilterRegistrationBean<TokenAuthFilter> registrarFiltro(TokenAuthFilter filtro) {
        FilterRegistrationBean<TokenAuthFilter> bean = new FilterRegistrationBean<>();
        bean.setFilter(filtro);
        bean.addUrlPatterns("/api/v1/notificaciones/*"); // protege los endpoints
        return bean;
    }
}
