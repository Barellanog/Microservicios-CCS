package com.codecraftstudios.admin_service.model;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "administradores")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Admin {

    @Id
    private Long id;

    @Column(nullable = false)
    private String nombre;

    @Column(nullable = false, unique = true)
    private String email;

    @Column(nullable = false)
    private String rolAsignado; // Por ejemplo: "SuperAdmin", "GestorPermisos"
}
