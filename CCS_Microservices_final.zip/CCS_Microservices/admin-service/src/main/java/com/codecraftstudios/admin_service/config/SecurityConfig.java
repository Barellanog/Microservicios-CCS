package com.codecraftstudios.admin_service.config;

public class SecurityConfig {
}
