package com.codecraftstudios.soporte_service.controller;

import com.codecraftstudios.soporte_service.dto.SoporteDTO;
import com.codecraftstudios.soporte_service.mapper.SoporteMapper;
import com.codecraftstudios.soporte_service.model.Soporte;
import com.codecraftstudios.soporte_service.service.SoporteService;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/v1/soporte")
public class SoporteController {

    @Autowired
    private SoporteService soporteService;

    @GetMapping
    public ResponseEntity<List<SoporteDTO>> listar() {
        List<SoporteDTO> soportes = soporteService.listarSoportes()
                .stream()
                .map(SoporteMapper::toDTO)
                .collect(Collectors.toList());

        return soportes.isEmpty()
                ? ResponseEntity.noContent().build()
                : ResponseEntity.ok(soportes);
    }

    @GetMapping("/{id}")
    public ResponseEntity<SoporteDTO> obtenerPorId(@PathVariable Long id) {
        return soporteService.obtenerPorId(id)
                .map(SoporteMapper::toDTO)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<SoporteDTO> crear(@RequestBody SoporteDTO dto) {
        Soporte creado = soporteService.crearSoporte(SoporteMapper.toEntity(dto));
        return ResponseEntity.status(201).body(SoporteMapper.toDTO(creado));
    }

    @PutMapping("/{id}")
    public ResponseEntity<SoporteDTO> actualizar(@PathVariable Long id, @RequestBody SoporteDTO dto) {
        return soporteService.actualizarSoporte(id, SoporteMapper.toEntity(dto))
                .map(SoporteMapper::toDTO)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        soporteService.eliminarSoporte(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/remitente/{email}")
    public ResponseEntity<List<SoporteDTO>> buscarPorRemitente(@PathVariable String email) {
        List<SoporteDTO> resultado = soporteService.buscarPorRemitente(email)
                .stream()
                .map(SoporteMapper::toDTO)
                .collect(Collectors.toList());

        return resultado.isEmpty()
                ? ResponseEntity.noContent().build()
                : ResponseEntity.ok(resultado);
    }

    @GetMapping("/estado/{estado}")
    public ResponseEntity<List<SoporteDTO>> buscarPorEstado(@PathVariable String estado) {
        List<SoporteDTO> resultado = soporteService.buscarPorEstado(estado)
                .stream()
                .map(SoporteMapper::toDTO)
                .collect(Collectors.toList());

        return resultado.isEmpty()
                ? ResponseEntity.noContent().build()
                : ResponseEntity.ok(resultado);
    }

    @GetMapping("/mis-solicitudes")
    public ResponseEntity<?> verMisSolicitudes(HttpServletRequest request) {
        String rol = (String) request.getAttribute("usuarioRol");
        String email = (String) request.getAttribute("usuarioEmail");

        if (email == null || (!"ESTUDIANTE".equals(rol) && !"INSTRUCTOR".equals(rol))) {
            return ResponseEntity.status(403).body("Acceso denegado");
        }

        return ResponseEntity.ok("Solicitudes de soporte creadas por: " + email);
    }

}
