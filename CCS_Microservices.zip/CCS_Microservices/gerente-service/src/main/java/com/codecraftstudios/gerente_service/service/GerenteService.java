package com.codecraftstudios.gerente_service.service;

import com.codecraftstudios.gerente_service.model.Gerente;
import com.codecraftstudios.gerente_service.repository.GerenteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class GerenteService {

    @Autowired
    private GerenteRepository gerenteRepository;

    public List<Gerente> listarGerentes() {
        return gerenteRepository.findAll();
    }

    public Optional<Gerente> obtenerGerentePorId(Long id) {
        return gerenteRepository.findById(id);
    }

    public Gerente crearGerente(Gerente gerente) {
        return gerenteRepository.save(gerente);
    }

    public Optional<Gerente> actualizarGerente(Long id, Gerente nuevoGerente) {
        return gerenteRepository.findById(id).map(gerenteExistente -> {
            gerenteExistente.setNombre(nuevoGerente.getNombre());
            gerenteExistente.setEmail(nuevoGerente.getEmail());
            gerenteExistente.setAreaResponsable(nuevoGerente.getAreaResponsable());
            return gerenteRepository.save(gerenteExistente);
        });
    }

    public void eliminarGerente(Long id) {
        gerenteRepository.deleteById(id);
    }
}
