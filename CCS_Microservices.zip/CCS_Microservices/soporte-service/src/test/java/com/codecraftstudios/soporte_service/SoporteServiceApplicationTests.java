package com.codecraftstudios.soporte_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SoporteServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
