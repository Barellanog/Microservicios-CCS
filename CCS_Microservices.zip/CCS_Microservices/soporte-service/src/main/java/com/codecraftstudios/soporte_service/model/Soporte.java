package com.codecraftstudios.soporte_service.model;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "soportes")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Soporte {

    @Id
    private Long id;

    @Column(nullable = false)
    private String titulo;

    @Column(nullable = false, columnDefinition = "TEXT")
    private String descripcion;

    @Column(nullable = false)
    private String remitenteEmail;

    @Column(nullable = false)
    private String estado; // Ejemplo: "Pendiente", "En revisión", "Resuelto"
}
