package com.codecraftstudios.soporte_service.service;

import com.codecraftstudios.soporte_service.model.Soporte;
import com.codecraftstudios.soporte_service.repository.SoporteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class SoporteService {

    @Autowired
    private SoporteRepository soporteRepository;

    public List<Soporte> listarSoportes() {
        return soporteRepository.findAll();
    }

    public Optional<Soporte> obtenerPorId(Long id) {
        return soporteRepository.findById(id);
    }

    public Soporte crearSoporte(Soporte soporte) {
        return soporteRepository.save(soporte);
    }

    public Optional<Soporte> actualizarSoporte(Long id, Soporte actualizado) {
        return soporteRepository.findById(id).map(soporteExistente -> {
            soporteExistente.setTitulo(actualizado.getTitulo());
            soporteExistente.setDescripcion(actualizado.getDescripcion());
            soporteExistente.setRemitenteEmail(actualizado.getRemitenteEmail());
            soporteExistente.setEstado(actualizado.getEstado());
            return soporteRepository.save(soporteExistente);
        });
    }

    public void eliminarSoporte(Long id) {
        soporteRepository.deleteById(id);
    }

    public List<Soporte> buscarPorRemitente(String email) {
        return soporteRepository.findByRemitenteEmail(email);
    }

    public List<Soporte> buscarPorEstado(String estado) {
        return soporteRepository.findByEstado(estado);
    }
}
