package com.codecraftstudios.curso_service.dto;

import com.codecraftstudios.curso_service.model.Rol;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CursoDTO {
    private Long id;
    private String nombre;
    private String descripcion;
    private String fecha;
    private String horaCurso;

    private String instructorNombre;
    private String instructorEmail;
    private Rol instructorRol; // Requiere tener Rol definido localmente

    public CursoDTO(Long id, String nombre, String descripcion, String fecha, String horaCurso) {
        this.id = id;
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.fecha = fecha;
        this.horaCurso = horaCurso;
    }
}
