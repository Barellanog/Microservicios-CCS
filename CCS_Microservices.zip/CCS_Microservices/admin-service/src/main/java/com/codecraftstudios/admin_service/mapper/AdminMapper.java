package com.codecraftstudios.admin_service.mapper;

import com.codecraftstudios.admin_service.dto.AdminDTO;
import com.codecraftstudios.admin_service.model.Admin;

public class AdminMapper {

    public static AdminDTO toDTO(Admin admin) {
        return new AdminDTO(
                admin.getId(),
                admin.getNombre(),
                admin.getEmail(),
                admin.getRolAsignado()
        );
    }

    public static Admin toEntity(AdminDTO dto) {
        Admin admin = new Admin();
        admin.setId(dto.getId());
        admin.setNombre(dto.getNombre());
        admin.setEmail(dto.getEmail());
        admin.setRolAsignado(dto.getRolAsignado());
        return admin;
    }
}
