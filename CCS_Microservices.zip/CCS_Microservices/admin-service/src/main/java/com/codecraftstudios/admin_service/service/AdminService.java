package com.codecraftstudios.admin_service.service;

import com.codecraftstudios.admin_service.model.Admin;
import com.codecraftstudios.admin_service.repository.AdminRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class AdminService {

    @Autowired
    private AdminRepository adminRepository;

    public List<Admin> listarAdmins() {
        return adminRepository.findAll();
    }

    public Optional<Admin> obtenerAdminPorId(Long id) {
        return adminRepository.findById(id);
    }

    public Admin crearAdmin(Admin admin) {
        return adminRepository.save(admin);
    }

    public Optional<Admin> actualizarAdmin(Long id, Admin nuevoAdmin) {
        return adminRepository.findById(id).map(adminExistente -> {
            adminExistente.setNombre(nuevoAdmin.getNombre());
            adminExistente.setEmail(nuevoAdmin.getEmail());
            adminExistente.setRolAsignado(nuevoAdmin.getRolAsignado());
            return adminRepository.save(adminExistente);
        });
    }

    public void eliminarAdmin(Long id) {
        adminRepository.deleteById(id);
    }
}
