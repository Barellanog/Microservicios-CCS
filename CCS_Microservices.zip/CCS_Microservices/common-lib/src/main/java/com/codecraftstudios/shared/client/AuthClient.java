package com.codecraftstudios.shared.client;

import com.codecraftstudios.shared.dto.TokenValidationResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
public class AuthClient {

    private final String AUTH_URL = "http://localhost:8080/api/v1/auth/validate-token";

    public TokenValidationResponse validarToken(String token) {
        try {
            String url = AUTH_URL + "?token=" + token;
            RestTemplate restTemplate = new RestTemplate();
            return restTemplate.getForObject(url, TokenValidationResponse.class);
        } catch (Exception e) {
            return new TokenValidationResponse(false, null, null);
        }
    }
}
