package com.codecraftstudios.shared.security;

import com.codecraftstudios.shared.client.AuthClient;
import com.codecraftstudios.shared.dto.TokenValidationResponse;
import jakarta.servlet.*;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;

@Component
public class TokenAuthFilter implements Filter {

    @Autowired
    private AuthClient authClient;

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {

        HttpServletRequest http = (HttpServletRequest) request;
        String header = http.getHeader("Authorization");

        if (header != null && header.startsWith("Bearer ")) {
            String token = header.substring(7);
            TokenValidationResponse result = authClient.validarToken(token);

            if (result.isValido()) {
                // Agrega el rol y email al request para que los controladores puedan usarlo
                http.setAttribute("usuarioEmail", result.getEmail());
                http.setAttribute("usuarioRol", result.getRol().name());

                chain.doFilter(request, response);
                return;
            }
        }

        // Si no hay token válido, rechazar con 401
        ((HttpServletResponse) response).sendError(HttpServletResponse.SC_UNAUTHORIZED, "Token inválido o ausente");
    }
}
