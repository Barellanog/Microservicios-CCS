package com.codecraftstudios.auth_service.service;

import com.codecraftstudios.auth_service.dto.*;
import com.codecraftstudios.auth_service.model.Usuario;
import com.codecraftstudios.auth_service.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Optional;
import java.util.UUID;

@Service
public class AuthService {

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    public AuthResponse registrar(RegistroRequest request) {
        if (usuarioRepository.findByEmail(request.getEmail()).isPresent()) {
            throw new RuntimeException("El email ya está registrado");
        }

        Usuario usuario = new Usuario();
        usuario.setNombre(request.getNombre());
        usuario.setEmail(request.getEmail());
        usuario.setPassword(passwordEncoder.encode(request.getPassword()));
        usuario.setRol(request.getRol());
        usuario.setToken(UUID.randomUUID().toString());

        usuarioRepository.save(usuario);

        return new AuthResponse(usuario.getToken());
    }

    public AuthResponse login(LoginRequest request) {
        Usuario usuario = usuarioRepository.findByEmail(request.getEmail())
                .orElseThrow(() -> new RuntimeException("Credenciales inválidas"));

        if (!passwordEncoder.matches(request.getPassword(), usuario.getPassword())) {
            throw new RuntimeException("Credenciales inválidas");
        }

        usuario.setToken(UUID.randomUUID().toString()); // nuevo token
        usuarioRepository.save(usuario);

        return new AuthResponse(usuario.getToken());
    }

    public TokenValidationResponse validarToken(String token) {
        Optional<Usuario> usuarioOpt = usuarioRepository.findByToken(token);
        if (usuarioOpt.isPresent()) {
            Usuario usuario = usuarioOpt.get();
            return new TokenValidationResponse(true, usuario.getEmail(), usuario.getRol());
        } else {
            return new TokenValidationResponse(false, null, null);
        }
    }
}
