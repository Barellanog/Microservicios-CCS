package com.codecraftstudios.notificacion_service.model;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "notificaciones")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Notificacion {

    @Id
    private Long id; // Ingresado manualmente desde Postman

    @Column(nullable = false)
    private String destinatarioEmail;

    @Column(nullable = false, columnDefinition = "TEXT")
    private String mensaje;

    @Column(nullable = false)
    private String tipo; // Ej: "ALERTA", "INFO", "ADVERTENCIA"

    @Column(nullable = false)
    private String estado; // Ej: "PENDIENTE", "ENVIADA"
}
