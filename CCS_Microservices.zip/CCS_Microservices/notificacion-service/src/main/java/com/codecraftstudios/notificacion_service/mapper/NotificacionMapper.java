package com.codecraftstudios.notificacion_service.mapper;

import com.codecraftstudios.notificacion_service.dto.NotificacionDTO;
import com.codecraftstudios.notificacion_service.model.Notificacion;

public class NotificacionMapper {

    public static NotificacionDTO toDTO(Notificacion noti) {
        return new NotificacionDTO(
                noti.getId(),
                noti.getDestinatarioEmail(),
                noti.getMensaje(),
                noti.getTipo(),
                noti.getEstado()
        );
    }

    public static Notificacion toEntity(NotificacionDTO dto) {
        Notificacion noti = new Notificacion();
        noti.setId(dto.getId());
        noti.setDestinatarioEmail(dto.getDestinatarioEmail());
        noti.setMensaje(dto.getMensaje());
        noti.setTipo(dto.getTipo());
        noti.setEstado(dto.getEstado());
        return noti;
    }
}
