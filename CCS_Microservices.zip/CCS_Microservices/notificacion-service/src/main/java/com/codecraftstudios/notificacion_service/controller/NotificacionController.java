package com.codecraftstudios.notificacion_service.controller;

import com.codecraftstudios.notificacion_service.dto.NotificacionDTO;
import com.codecraftstudios.notificacion_service.mapper.NotificacionMapper;
import com.codecraftstudios.notificacion_service.model.Notificacion;
import com.codecraftstudios.notificacion_service.service.NotificacionService;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/v1/notificaciones")
public class NotificacionController {

    @Autowired
    private NotificacionService notificacionService;

    @GetMapping
    public ResponseEntity<List<NotificacionDTO>> listar() {
        List<NotificacionDTO> notificaciones = notificacionService.listarNotificaciones()
                .stream()
                .map(NotificacionMapper::toDTO)
                .collect(Collectors.toList());

        return notificaciones.isEmpty()
                ? ResponseEntity.noContent().build()
                : ResponseEntity.ok(notificaciones);
    }

    @GetMapping("/{id}")
    public ResponseEntity<NotificacionDTO> obtenerPorId(@PathVariable Long id) {
        return notificacionService.obtenerPorId(id)
                .map(NotificacionMapper::toDTO)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<NotificacionDTO> crear(@RequestBody NotificacionDTO dto) {
        Notificacion creada = notificacionService.crearNotificacion(NotificacionMapper.toEntity(dto));
        return ResponseEntity.status(201).body(NotificacionMapper.toDTO(creada));
    }

    @PutMapping("/{id}")
    public ResponseEntity<NotificacionDTO> actualizar(@PathVariable Long id, @RequestBody NotificacionDTO dto) {
        return notificacionService.actualizarNotificacion(id, NotificacionMapper.toEntity(dto))
                .map(NotificacionMapper::toDTO)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        notificacionService.eliminarNotificacion(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/destinatario/{email}")
    public ResponseEntity<List<NotificacionDTO>> buscarPorEmail(@PathVariable String email) {
        List<NotificacionDTO> resultado = notificacionService.buscarPorEmail(email)
                .stream()
                .map(NotificacionMapper::toDTO)
                .collect(Collectors.toList());

        return resultado.isEmpty()
                ? ResponseEntity.noContent().build()
                : ResponseEntity.ok(resultado);
    }

    @GetMapping("/estado/{estado}")
    public ResponseEntity<List<NotificacionDTO>> buscarPorEstado(@PathVariable String estado) {
        List<NotificacionDTO> resultado = notificacionService.buscarPorEstado(estado)
                .stream()
                .map(NotificacionMapper::toDTO)
                .collect(Collectors.toList());

        return resultado.isEmpty()
                ? ResponseEntity.noContent().build()
                : ResponseEntity.ok(resultado);
    }

    @GetMapping("/tipo/{tipo}")
    public ResponseEntity<List<NotificacionDTO>> buscarPorTipo(@PathVariable String tipo) {
        List<NotificacionDTO> resultado = notificacionService.buscarPorTipo(tipo)
                .stream()
                .map(NotificacionMapper::toDTO)
                .collect(Collectors.toList());

        return resultado.isEmpty()
                ? ResponseEntity.noContent().build()
                : ResponseEntity.ok(resultado);
    }

    @GetMapping("/mias")
    public ResponseEntity<?> verMisNotificaciones(HttpServletRequest request) {
        String rol = (String) request.getAttribute("usuarioRol");
        String email = (String) request.getAttribute("usuarioEmail");

        // Cualquier rol válido puede revisar sus propias notificaciones
        if (rol == null || email == null) {
            return ResponseEntity.status(403).body("Acceso denegado");
        }

        return ResponseEntity.ok("Notificaciones enviadas a: " + email);
    }

}
