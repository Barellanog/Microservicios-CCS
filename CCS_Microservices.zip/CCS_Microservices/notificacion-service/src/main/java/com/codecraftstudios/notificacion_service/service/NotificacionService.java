package com.codecraftstudios.notificacion_service.service;

import com.codecraftstudios.notificacion_service.model.Notificacion;
import com.codecraftstudios.notificacion_service.repository.NotificacionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class NotificacionService {

    @Autowired
    private NotificacionRepository notificacionRepository;

    public List<Notificacion> listarNotificaciones() {
        return notificacionRepository.findAll();
    }

    public Optional<Notificacion> obtenerPorId(Long id) {
        return notificacionRepository.findById(id);
    }

    public Notificacion crearNotificacion(Notificacion notificacion) {
        return notificacionRepository.save(notificacion);
    }

    public Optional<Notificacion> actualizarNotificacion(Long id, Notificacion actualizada) {
        return notificacionRepository.findById(id).map(notiExistente -> {
            notiExistente.setDestinatarioEmail(actualizada.getDestinatarioEmail());
            notiExistente.setMensaje(actualizada.getMensaje());
            notiExistente.setTipo(actualizada.getTipo());
            notiExistente.setEstado(actualizada.getEstado());
            return notificacionRepository.save(notiExistente);
        });
    }

    public void eliminarNotificacion(Long id) {
        notificacionRepository.deleteById(id);
    }

    public List<Notificacion> buscarPorEmail(String email) {
        return notificacionRepository.findByDestinatarioEmail(email);
    }

    public List<Notificacion> buscarPorEstado(String estado) {
        return notificacionRepository.findByEstado(estado);
    }

    public List<Notificacion> buscarPorTipo(String tipo) {
        return notificacionRepository.findByTipo(tipo);
    }
}
