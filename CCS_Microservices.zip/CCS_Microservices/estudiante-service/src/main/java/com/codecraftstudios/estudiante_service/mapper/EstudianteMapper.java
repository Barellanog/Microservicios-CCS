package com.codecraftstudios.estudiante_service.mapper;

import com.codecraftstudios.estudiante_service.dto.EstudianteDTO;
import com.codecraftstudios.estudiante_service.model.Estudiante;

public class EstudianteMapper {

    public static EstudianteDTO toDTO(Estudiante estudiante) {
        return new EstudianteDTO(
                estudiante.getId(),
                estudiante.getNombre(),
                estudiante.getEmail(),
                estudiante.getCarrera()
        );
    }

    public static Estudiante toEntity(EstudianteDTO dto) {
        Estudiante estudiante = new Estudiante();
        estudiante.setId(dto.getId());
        estudiante.setNombre(dto.getNombre());
        estudiante.setEmail(dto.getEmail());
        estudiante.setCarrera(dto.getCarrera());
        return estudiante;
    }
}
