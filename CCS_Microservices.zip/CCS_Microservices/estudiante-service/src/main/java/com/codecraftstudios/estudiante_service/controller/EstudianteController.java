package com.codecraftstudios.estudiante_service.controller;

import com.codecraftstudios.estudiante_service.dto.EstudianteDTO;
import com.codecraftstudios.estudiante_service.mapper.EstudianteMapper;
import com.codecraftstudios.estudiante_service.model.Estudiante;
import com.codecraftstudios.estudiante_service.service.EstudianteService;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/v1/estudiantes")
public class EstudianteController {

    @Autowired
    private EstudianteService estudianteService;

    @GetMapping
    public ResponseEntity<List<EstudianteDTO>> listar() {
        List<EstudianteDTO> estudiantes = estudianteService.listarEstudiantes()
                .stream()
                .map(EstudianteMapper::toDTO)
                .collect(Collectors.toList());

        return estudiantes.isEmpty()
                ? ResponseEntity.noContent().build()
                : ResponseEntity.ok(estudiantes);
    }

    @GetMapping("/{id}")
    public ResponseEntity<EstudianteDTO> obtenerPorId(@PathVariable Long id) {
        return estudianteService.obtenerEstudiantePorId(id)
                .map(EstudianteMapper::toDTO)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<EstudianteDTO> crear(@RequestBody EstudianteDTO dto) {
        Estudiante creado = estudianteService.crearEstudiante(EstudianteMapper.toEntity(dto));
        return ResponseEntity.status(201).body(EstudianteMapper.toDTO(creado));
    }

    @PutMapping("/{id}")
    public ResponseEntity<EstudianteDTO> actualizar(@PathVariable Long id, @RequestBody EstudianteDTO dto) {
        return estudianteService.actualizarEstudiante(id, EstudianteMapper.toEntity(dto))
                .map(EstudianteMapper::toDTO)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        estudianteService.eliminarEstudiante(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/perfil")
    public ResponseEntity<?> verPerfil(HttpServletRequest request) {
        String rol = (String) request.getAttribute("usuarioRol");
        String email = (String) request.getAttribute("usuarioEmail");

        if (!"ESTUDIANTE".equals(rol)) {
            return ResponseEntity.status(403).body("Acceso denegado");
        }

        return ResponseEntity.ok("Perfil del estudiante con correo: " + email);
    }
}
